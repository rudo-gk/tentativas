const express = require('express');
const lodash = require('lodash');
const axios = require('axios');
const app = express();

async function procurarnaapi(){
    try{
        const result = await axios.get('https://api.tvmaze.com/search/shows?q=Wednesday');
        const serie = result.data.find(item => item.show.name === 'Wednesday');
        console.log(serie)
        return serie;

    }catch{
        console.log("erro");

    }

}

app.get('/', async(req, res) => {
    const serie = await procurarnaapi();


    res.json(serie);
});

app.listen(3000, () => { 
    console.log('Servidor rodando em http://localhost:3000'); 
});