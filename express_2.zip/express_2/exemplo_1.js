const express = require('express'); 
const app = express(); 

app.get('/', (req, res) => { 
    res.send('Olá, mundo!'); 
}); 
// Exemplo 2: rota /sobre (JSON) 
app.get('/sobre', (req, res) => { 
    res.json({ projeto: 'Aula  02', disciplina: 'WEB' }); 
}); 
// Servidor ouvindo na porta 3000 
app.listen(3000, () => { 
    +console.log('Servidor rodando em http://localhost:3000'); 
});